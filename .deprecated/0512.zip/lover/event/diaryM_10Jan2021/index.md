# 小木的日记

> diaryM_10Jan2021

[image1](https://s3.ax1x.com/2021/01/18/s6x7YF.jpg)

[image2](https://s3.ax1x.com/2021/01/18/s6xTFU.jpg)